.. Copyright (c) 2016, Johan Mabille, Sylvain Corlay and Wolf Vollprecht

   Distributed under the terms of the BSD 3-Clause License.

   The full license is in the file LICENSE, distributed with this software.

xcontainer_semantic
===================

Defined in ``xtensor/xsemantic.hpp``

.. doxygenclass:: xt::xcontainer_semantic
   :members:
