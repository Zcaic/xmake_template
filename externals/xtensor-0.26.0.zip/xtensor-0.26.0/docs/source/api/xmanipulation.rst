.. Copyright (c) 2016, Johan Mabille, Sylvain Corlay, Wolf Vollprecht and Martin Renou

   Distributed under the terms of the BSD 3-Clause License.

   The full license is in the file LICENSE, distributed with this software.

xmanipulation
=============

Defined in ``xtensor/xmanipulation.hpp``

.. cpp:namespace-push:: xt

.. doxygengroup:: xt_xmanipulation

.. cpp:namespace-pop::
